export class Products {

	 id:number ;
    productName:string;
    productPrice: number
}
