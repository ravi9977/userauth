
export interface ILogin {
     username: "TestAdmin",
    password: "admin@123"
     }
